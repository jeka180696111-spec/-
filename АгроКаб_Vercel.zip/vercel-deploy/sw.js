const CACHE='agrokab-v7';
const ASSETS=['/'];

self.addEventListener('install',function(e){
  e.waitUntil(caches.open(CACHE).then(function(c){return c.addAll(ASSETS);}));
  self.skipWaiting();
});

self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(keys){
    return Promise.all(keys.filter(function(k){return k!==CACHE;}).map(function(k){return caches.delete(k);}));
  }));
  self.clients.claim();
});

self.addEventListener('fetch',function(e){
  if(e.request.method!=='GET')return;
  if(e.request.url.indexOf('supabase')>=0||e.request.url.indexOf('anthropic')>=0||e.request.url.indexOf('netlify/functions')>=0)return;
  e.respondWith(
    caches.match(e.request).then(function(r){
      return r||fetch(e.request).then(function(resp){
        var rc=resp.clone();
        caches.open(CACHE).then(function(c){c.put(e.request,rc);});
        return resp;
      }).catch(function(){return r;});
    })
  );
});
