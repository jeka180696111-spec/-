export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) return res.status(500).json({ error: 'No API key' });

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-beta': 'web-search-2025-03-05'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 500,
        tools: [{ type: 'web_search_20250305', name: 'web_search' }],
        messages: [{
          role: 'user',
          content: 'Знайди актуальні закупівельні ціни на зерно в Україні сьогодні (грн/тонна). Поверни ТІЛЬКИ JSON: {"wheat":ЧИСЛО,"sunflower":ЧИСЛО,"corn":ЧИСЛО,"rapeseed":ЧИСЛО,"barley":ЧИСЛО,"soy":ЧИСЛО,"updated":"дата"}'
        }]
      })
    });

    const data = await response.json();
    let text = '';
    if (data.content) {
      for (const block of data.content) {
        if (block.type === 'text') text += block.text;
      }
    }
    const jsonMatch = text.match(/\{[^{}]+\}/);
    if (jsonMatch) return res.status(200).json(JSON.parse(jsonMatch[0]));
    return res.status(200).json({ error: 'No prices found' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
